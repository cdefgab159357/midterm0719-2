<?php
if (isset($_GET['product_id'])) {
include("connect.php");
$product_id = $_GET['product_id'];
$sql = "DELETE FROM books WHERE product_id='$product_id'";
if(mysqli_query($conn,$sql)){
    session_start();
    $_SESSION["delete"] = "Book Deleted Successfully!";
    header("Location:index_pro.php");
}else{
    die("Something went wrong");
}
}else{
    echo "Book does not exist";
}
?>
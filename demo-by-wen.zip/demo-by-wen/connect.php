<?php
$dbName = "product_info";
$dbHost = "localhost";
$dbUser = "root";
$dbPass = "heidid08";
$conn = mysqli_connect($dbHost, $dbUser, $dbPass, $dbName);
if (!$conn) {
    die("Something went wrong");
}
?>
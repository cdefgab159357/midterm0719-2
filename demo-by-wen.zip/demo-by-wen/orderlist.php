<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

  <link rel="stylesheet" href="style.css">
  <title>Product List</title>
  <style>
    table td,
    table th {
      background-color: #fff;
      vertical-align: middle;
      text-align: right;
      padding: 20px !important;
    }

    @import url();

    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: "Franklin Gothic Medium", "Arial Narrow", Arial, sans-serif;
    }

    body {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      background: lightslategray;
    }

    ul {
      position: relative;
      transform: skewY(-15deg);
      margin-left: 100px;
    }

    ul li {
      position: relative;
      list-style: none;
      width: 200px;
      background: #3e3f46;
      padding: 15px;
      z-index: var(--i);
      transition: 0.3s;
    }

    ul li:hover {
      background: #00E3E3;
      transform: translateX(-30px);
    }

    .li2:hover {
      background: #00E3E3;
      transform: translateX(30px);
    }

    ul li::before {
      content: "  ";
      position: absolute;
      top: 0;
      left: -40px;
      width: 40px;
      height: 100%;
      background: #2e3133;
      transform-origin: right;
      transform: skewY(45deg);
    }

    ul li:hover::before {
      background: #1f5378;
    }

    ul li::after {
      content: "  ";
      position: absolute;
      top: -40px;
      left: 0;
      width: 100%;
      height: 40px;
      background: #35383e;
      transform-origin: bottom;
      transform: skewX(45deg);
      transition: 0.5s;
    }

    ul li:hover::after {
      background-color: #2982b9;
    }

    ul li a {
      text-decoration: none;
      color: #999;
      display: block;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      transition: 0.5s;
    }

    ul li:hover a {
      color: #fff;
    }

    ul li:last-child::after {
      box-shadow: -100px 100px 20px rgba(0, 0, 0, 0.5);
    }
  </style>
</head>

<body>
<ul class="fixed-top">
    <li style="--i:4"><a href="pro-add.php">新增商品</a></li>
    <li style="--i:3"><a href="index_pro.php">商品列表</a></li>
    <li style="--i:2"><a href="orderlist.php">訂單編號</a></li>
    <li style="--i:1"><a href="orderlist-detail.php">訂單詳情</a></li>
  </ul>
  <div class="container my-4">
    <header class="d-flex justify-content-between my-4">
      <h1>Order List</h1>
      <div>
        <a href="or-add.php" class="btn btn-primary">新增訂單</a>
      </div>
    </header>

    <form action="search.php" method="GET" class="mb-3">
      <div class="input-group">
        <input type="text" class="form-control" placeholder="輸入搜尋關鍵字" name="keyword">
        <button class="btn btn-primary" type="submit">搜尋</button>
      </div>
    </form>

    <?php
    session_start();
    if (isset($_SESSION["create"])) {
    ?>
      <div class="alert alert-success">
        <?php
        echo $_SESSION["create"];
        ?>
      </div>
    <?php
      unset($_SESSION["create"]);
    }
    ?>
    <?php
    if (isset($_SESSION["edit"])) {
    ?>
      <div class="alert alert-success">
        <?php
        echo $_SESSION["edit"];
        ?>
      </div>
    <?php
      unset($_SESSION["edit"]);
    }
    ?>
    <?php
    if (isset($_SESSION["delete"])) {
    ?>
      <div class="alert alert-success">
        <?php
        echo $_SESSION["delete"];
        ?>
      </div>
    <?php
      unset($_SESSION["delete"]);
    }
    ?>

    <table class="table table-bordered bg-success p-2 text-white bg-opacity-10">
      <thead>
        <tr>
          <th>訂單編號</th>
          <th>訂單日期</th>
          <th>付款方式</th>
          <th>配送狀態</th>
          <th>總金額</th>
          <th>使用者id</th>
          <th>使用者姓名</th>
          <th>寄送地址</th>
          <th>操作按鈕</th>
        </tr>
      </thead>
      <tbody>

        <?php
        include('connect.php');
        $sqlSelect = "SELECT * FROM orderlist 
        join user_data on orderlist.user_id = user_data.user_id
        ";
        $result = mysqli_query($conn, $sqlSelect);
        while ($data = mysqli_fetch_array($result)) {
        ?>
          <tr>
            <td>
            <a href="orderlist-detail.php?product_order_id=<?= $data['product_order_id']; ?>"><?= $data['product_order_id']; ?></a>
          </td>
          <td><?php echo $data['order_date']; ?></td>
            <td><?php echo $data['product_payment']; ?></td>
            <td><?php echo $data['deliver_status']; ?></td>
            <td><?php echo $data['product_total_price']; ?></td>
            <td><?php echo $data['user_id']; ?></td>
            <td><?php echo $data['user_name']; ?></td>
            <td><?php echo $data['user_address']; ?></td>
            <td>
              <a href="pro-view.php?product_order_id=<?php echo $data['product_order_id']; ?>" class="btn btn-info">更多</a>
              <a href="or-edit.php?product_order_id=<?php echo $data['product_order_id']; ?>" class="btn btn-warning">編輯</a>
              <a href="or-delete.php?product_order_id=<?php echo $data['product_order_id']; ?>" class="btn btn-danger">刪除</a>
            </td>
          </tr>
        <?php
        }
        ?>
      </tbody>
    </table>
  </div>
</body>

</html>